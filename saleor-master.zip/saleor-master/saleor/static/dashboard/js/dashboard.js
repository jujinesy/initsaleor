import 'materialize-css/dist/js/materialize';
import 'jquery.cookie';

import '../scss/dashboard.scss';
import './components';
