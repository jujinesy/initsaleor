Continuous Integration
======================

The storefront ships with a working `CircleCI <https://circleci.com/>`_ configuration file.
To use it log into your CircleCI account and enable your repository.
