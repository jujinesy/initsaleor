Architecture
============

.. toctree::
   :maxdepth: 1

   architecture/money
   architecture/products
   architecture/thumbnails
   architecture/stock
   architecture/orders
   architecture/i18n
   architecture/search
   architecture/payments
   architecture/settings
   architecture/page
