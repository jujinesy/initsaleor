Contributing Guides
===================

Please use GitHub issues and pull requests to report problems and discuss new features.


.. toctree::
   :maxdepth: 1

   contributing/editorconfig
   contributing/coding-style
   contributing/naming
